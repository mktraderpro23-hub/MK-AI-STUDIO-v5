# MK AI STUDIO V5 Premium

One file, no server, no API keys. Open index.html or host it (Render Static Site, GitHub Pages, Netlify).
Login is a front-end gate only (see note in chat). The access code is stored as a hash in index.html (PASS_HASH).
